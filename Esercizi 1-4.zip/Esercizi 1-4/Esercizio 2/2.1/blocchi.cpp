#include "blocchi.h"

#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <cstring>
#include <iostream>
using namespace std;


//*********COSTRUTTORI***********//

blocchi::blocchi(int dimensione, int blocchi){
    dimensione_=dimensione;
    blocchi_=blocchi;
    dim_blocchi= dimensione/blocchi;
    vettore_media = new double[blocchi_];
    vettore_errori = new double[blocchi_];
    cout<<"blocchi: "<<blocchi_<<endl;
    cout<<"dim_blocchi: "<<dim_blocchi<<endl;
    cout<<"dimensione_: "<<dimensione_<<endl<<endl;
}
void blocchi::do_it (double * vettore) {
    
    av_progress = new double[blocchi_];
    double*av_progress2 = new double[blocchi_];

    for(int i=0; i<blocchi_;i++){vettore_errori[i]=0;av_progress[i]=0;av_progress2[i]=0;}
    
    for(int i=0;i<blocchi_; i++){
        for(int j=0; j<dim_blocchi;j++){
        int k= i*dim_blocchi+j;
        vettore_media[i]+=vettore[k];
        }
    vettore_media[i]/=dim_blocchi;
    }
    av_progress[0] = vettore_media[0];
    av_progress2[0] = vettore_media[0]*vettore_media[0];

    for(int i=1; i<blocchi_;i++){
        for(int j=0; j<i; j++){
                av_progress[i]+=vettore_media[j];
                av_progress2[i]+=vettore_media[j]*vettore_media[j];
            }
        av_progress[i]/=i;
        av_progress2[i]/=i;
        
        vettore_errori[i]=(abs(av_progress2[i] - pow(av_progress[i],2)))/(i-1);

        vettore_errori[i] = sqrt(vettore_errori[i]);
    }

    return;
}


        
void blocchi::do_set_error(double * vettore, double * vettore_errori_){
    
    av_progress = new double[blocchi_];
    double*av_progress2 = new double[blocchi_];

    for(int i=0; i<blocchi_;i++){vettore_errori[i]=0;av_progress[i]=0;av_progress2[i]=0;}
    
    for(int i=0;i<blocchi_; i++){
        for(int j=0; j<dim_blocchi;j++){
        int k= i*dim_blocchi+j;
        vettore_media[i]+=vettore[k];
        }
    vettore_media[i]/=dim_blocchi;
    }
    av_progress[0] = vettore_media[0];
    av_progress2[0] = vettore_media[0]*vettore_media[0];

    for(int i=1; i<blocchi_;i++){
        for(int j=0; j<i; j++){
                av_progress[i]+=vettore_media[j];
                av_progress2[i]+=vettore_errori_[j];
            }
        av_progress[i]/=i;
        av_progress2[i]/=i;
        
        vettore_errori[i]=av_progress2[i];

        //vettore_errori[i] = sqrt(vettore_errori[i]);
    }

    return;
}




double blocchi::get(int indice){
    return av_progress[indice];
}

double blocchi::get_error(int indice){
    return vettore_errori[indice];
}

void blocchi::stampa (string nomefile){
    
    ostampa.open(nomefile);
    for (int i=0; i<blocchi_; i++){
        ostampa<<av_progress[i]<<"    "<<vettore_errori[i]<<endl;
    }
    ostampa.close();
    return;
}






