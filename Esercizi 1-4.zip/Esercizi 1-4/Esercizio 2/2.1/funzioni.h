#ifndef _funzioni_h_
#define _funzioni_h_
#include <cmath>

class funzioneBase {

public:
	virtual double eval(double x) const=0;
};


//Parabola ax^2+bx+c
class parabola : public funzioneBase {
public:
	parabola ();
	parabola (double a, double b, double c);
	~parabola () {}

	double eval (double x) const;
	void setA (double a) {_a=a;}
	void setB (double b) {_b=b;}
	void setC (double c) {_c=c;}
	double a () {return _a;}
	double b () {return _b;}
	double c () {return _c;}

private:
double _a,_b,_c;
};


class retta : public funzioneBase {
public:
    retta ();
    retta (double m, double q);
    ~retta () {}

    double eval (double x) const;
    void setM (double m) {_m=m;}
    void setQ (double q) {_q=q;}
    double m () {return _m;}
    double q () {return _q;}

private:
    double _m,_q;
};

class cos1 : public funzioneBase {
public:
    cos1 ();
    //cos1 (double a, double b);

    double eval (double x) const;

/*private:
    double _a,_b;*/
};
class cos2 : public funzioneBase {
public:
    cos2 ();
    //cos2 (double a, double b);


    double eval (double x) const;

/*private:
    double _a,_b;*/
};



//Seno
class seno: public funzioneBase {
public:
	seno () {};	
	double eval (double x) const {return sin(x);}
};


//funzione generica per test
class funzione : public funzioneBase {
public:
    funzione () {}
    double eval (double x) const {return 0/*INSERIRE LA FUNZIONE QUI*/;}
};

//funzione segno per metodo bisezione
int sign (double);

    
    
    
    
    

    
    
#endif
