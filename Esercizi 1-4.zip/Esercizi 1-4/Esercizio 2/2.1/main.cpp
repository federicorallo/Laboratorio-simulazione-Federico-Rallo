//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;


#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "blocchi.h"

#include "integrali.h"

#include "funzioni.h"




int main(){
    
    Random rnd;
    rnd.Random_std(&rnd);
    
    funzioneBase *f1 = new cos1();
    funzioneBase *f2 = new cos2();

    double*I1 = new double[10000];
    double*I2 = new double[10000];
    double*I1_2 = new double[10000];
    double*I2_2 = new double[10000];
    double*err1 = new double[10000];
    double*err2 = new double[10000];
    
    
    integral integrale1 (0 , 1, f1);
    integral integrale2 (0 , 1, f2);
    double bella = integrale1.midPointMCU( 10000, I1);
    double ciao = integrale2.midPointMCF( 10000, I2);
    integrale1.midPointMCU_2( 10000, I1_2);
    integrale2.midPointMCF_2( 10000, I2_2);
    
    for(int i=0; i<10000;i++){
        err1[i]= (abs(I1_2[i]-pow(I1[i],2)));
        err2[i]= (abs(I2_2[i]-pow(I2[i],2)));
        //cout<<I1_2[i]<<","<<pow(I1[i],2)<<endl;
        //cout<<I1[i]<<","<<I2[i]<<endl;

    }
    
    double*media_err1 = new double[100];
    double*media_err2 = new double[100];
    double*media_I1 = new double[100];
    double*media_I2 = new double[100];
    double m1 = 0;
    double m2 = 0;
    double e1 = 0;
    double e2 = 0;
    int z;
    double bho=0;
    
    for(int i=0; i<100;i++){
        for(int j=0; j<100;j++){
            z = int(i*100 + j);
            m1+=I1[z];
            m2+=I2[z];
        }
        media_I1[i] = double(m1/(100*(i+1)));
        media_I2[i]= double(m2/(100*(i+1)));
    }
    
    for(int i=0; i<100;i++){media_err1[i]=0;media_err2[i]=0;}

    
    for(int i=0; i<100;i++){
        for(int j=0; j<100;j++){
            int z= i*100 + j;
            e1+=err1[z];
            e2+=err2[z];
//            cout<<err2[z]<<endl;
        }
        media_err1[i]=(e1/100/(i+1));
        media_err2[i]=(e2/100/(i+1));
        media_err1[i]=sqrt(media_err1[i]);
        media_err2[i]=sqrt(media_err2[i]);
        cout<<media_err2[i]<<endl;
    }

    
    
    ofstream Output1;
    Output1.open("I1.dat");
    for (int i=0; i<100; i++){
        Output1<<media_I1[i]<<"  "<< media_err1[i]<<endl;
    }
    Output1.close();
    
    ofstream Output2;
    Output2.open("I2.dat");
    for (int i=0; i<100; i++){
        Output2<<media_I2[i]<<"  "<< media_err2[i]<<endl;
    }
    Output2.close();

    return 0;
}
