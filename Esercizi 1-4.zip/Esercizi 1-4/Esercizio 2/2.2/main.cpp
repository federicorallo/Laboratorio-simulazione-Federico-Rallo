//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "funzioni.h"
#include "integrali.h"


int main(){
    
    Random rnd;
    rnd.Random_std(&rnd);
    int N=10000;

    double a = 1;
    double*r_medio=new double [100];
    double*sigma=new double [100];
    double*err=new double [100];
    double*distanza = new double[N];
    
    
    for(int k=0; k<100; k++){
        for (int i=0; i<N; i++){
            double x=0;
            double y=0;
            double z=0;
    
            for (int j=0; j<k; j++){
                double p = rnd.Rannyu();
                if (p<1./3){
                    if(p<1./6) x+=a;
                    else x+=-a;
                }
                if (p>1./3 && p<2./3){
                    if(p<0.5) y+=a;
                    else y+=-a;
                }
                if (p>2./3){
                    if(p<5./6) z+=a;
                    else z+=-a;
                }
            }
        distanza[i] = sqrt(x*x+y*y+z*z);
        }
        r_medio[k]=0;
        sigma[k]=0;
        for (int i=0; i<N;i++) {r_medio[k]+=distanza[i];}
        r_medio[k]/=N;
        for(int i=0; i<N; i++) {sigma[k]+=fabs(pow(distanza[i],2)-pow(r_medio[k],2));}
    sigma[k]/=N;
    err[k]=sqrt(sigma[k]/(N-1));
    }
    
    
    
    ofstream Output;
    Output.open("Random_walk_reticolo");
    for(int i=0; i<100;i++){
        Output<<r_medio[i]<<" +- "<<err[i]<<endl;
    }
    Output.close();
    
    for(int k=0; k<100; k++){
        for (int i=0; i<N; i++){
    
            double x=0;
            double y=0;
            double z=0;
    
            for (int j=0; j<k; j++){
        
                double theta = rnd.Rannyu()*M_PI;
                double phi = rnd.Rannyu()*M_PI;
                x+=sin(theta)*cos(phi);
                y+=sin(theta)*cos(phi);
                z=cos(theta);
            }

    
            distanza[i] = sqrt(x*x+y*y+z*z);
        }
    
        r_medio[k]=0;
        sigma[k]=0;
        for (int i=0; i<N;i++) {r_medio[k]+=distanza[i];}
        r_medio[k]/=N;
        
        for(int i=0; i<N; i++) {sigma[k]+=fabs(pow(distanza[i],2)-pow(r_medio[k],2));}
        sigma[k]/=N;
        err[k]=sqrt(sigma[k]/(N-1));
    }
    
    Output.open("Random_walk_continuo");
    for(int i=0; i<100;i++){
        Output<<r_medio[i]<<" +- "<<err[i]<<endl;
    }
    Output.close();
    
    
    
    
    return 0;
}
