#include "integrali.h"
#include "random.h"
#include "funzioni.h"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
using namespace std;


//*********COSTRUTTORI***********//

integral::integral(double a, double b, funzioneBase * f){
	if (a<=b){
	_a=a;
	_b=b;
	_sign=1;
	} else {
	_a=b;
	_b=a;
	_sign=-1;
	}
	_integrand=f;
    _nSteps=1000; //inizializzo comunque a valori ragionevoli per steps e precisione per i metodi che fanno da soli senza richiederli
    _precision=1E-10;
    _integral=0; //inizializzo il valore dell'integrale a zero se lo chiamassi per sbaglio
}

integral::integral (double a, double b, funzioneBase * f, int nSteps){
    if (a<=b){
        _a=a;
        _b=b;
        _sign=1;
    } else {
        _a=b;
        _b=a;
        _sign=-1;
    }
    _integrand=f;
    _nSteps=nSteps;
    _precision=1E-10;//metto comunque un valore per la precisione se dovessi chiamare un metodo che usa il datamembro senza inizializzarlo
    _integral=0; //inizializzo il valore dell'integrale a zero se lo chiamassi per sbaglio
}

integral::integral (double a, double b, funzioneBase * f, double precision){
    if (a<=b){
        _a=a;
        _b=b;
        _sign=1;
    } else {
        _a=b;
        _b=a;
        _sign=-1;
    }
    _integrand=f;
    _nSteps=1000;//metto comunque un valore per nSteps se dovessi chiamare un metodo che usa il datamembro senza inizializzarlo
    _precision=precision;
    _integral=0; //inizializzo il valore dell'integrale a zero se lo chiamassi per sbaglio
}


//**********IMPOSTAZIONE DATAMEMBRI***********//

void integral::setA (double a) {
    _a=a;
    if (a>_b) _sign = -1;
    if (a<=_b) _sign = 1;
}

void integral::setB (double b) {
    _b=b;
    if (b<_a) _sign = -1;
    if (b>=_a) _sign = 1;
}



//**********METODO MIDPOINT************//

double integral::midPoint (int nSteps) {
	_sum=0.;
	_nSteps=nSteps;
	_h= (_b-_a)/nSteps;
	for (int i=0; i<nSteps; i++) {
		double x = _a + (i+0.5)*_h; 	//ascissa del punto medio di ciascun intervallino
		_sum += _integrand->eval(x);	// sommo i valori di f --> integrale = [f(x1)+f(x2)+...+f(xn)]*h
	}
	_integral=_sign*_sum*_h;
	return _integral;
}


//*************METODO SIMPSON************//

double integral::simpson (int nSteps) {
	_sum=0.;
	_nSteps=nSteps;
	if (nSteps%2==1) {
		cout << "ATTENZIONE: Metodo Simpson funziona con numero di passaggi pari. Integro con " << nSteps+1 << " passaggi"<<endl<<endl;
		_nSteps=nSteps+1;
	}
		_h= (_b-_a)/_nSteps;
	for (int i=0; i<nSteps; i++){
		if( i==0 || i==nSteps) _sum+=(_integrand->eval(_a+i*_h))/3;
		else { 
			if (i%2==0) _sum+=(_integrand->eval(_a+i*_h))*2/3;
			else _sum +=(_integrand->eval(_a+i*_h))*4/3;
		}
	}
	_integral=_sign*_sum*_h;
	return _integral;
}





//**********METODO MIDPOINT MC ************//

double integral::midPointMCU (int i_rnd) {
    _sum=0.;
    int _i_rnd=i_rnd;
    _h= (_b-_a)/_i_rnd;
    _rnd.Random_std(&_rnd);

    for (int i=0; i<_i_rnd; i++) {
        double n_r= _rnd.Rannyu();
        double x = _a + _b * n_r;     //ascissa del punto medio di ciascun intervallino
        _sum += _integrand->eval(x);    // sommo i valori di f --> integrale = [f(x1)+f(x2)+...+f(xn)]*h
    }
    _integral=_sign*_sum*_h;
    return _integral;
}

double integral::midPointMCF (int i_rnd) {
    _sum=0.;
    _rnd.Random_std(&_rnd);
    int _i_rnd=i_rnd;
    _h= (_b-_a)/_i_rnd;
    for (int i=0; i<_i_rnd; i++) {
        double R = _rnd.Rannyu();
        double n_r=1-sqrt(1.- (R)*8/pow(M_PI,2))+1;
        double x = _a + _b * n_r;     //ascissa del punto medio di ciascun intervallino
        _sum += _integrand->eval(x);    // sommo i valori di f --> integrale = [f(x1)+f(x2)+...+f(xn)]*h
    }
    _integral=_sign*_sum*_h;
    return _integral;
}

double integral::midPointMCU_2 (int i_rnd) {
    _sum=0.;
    int _i_rnd=i_rnd;
    _rnd.Random_std(&_rnd);
    _h= (_b-_a)/_i_rnd;
    for (int i=0; i<_i_rnd; i++) {
        double n_r= _rnd.Rannyu();
        double x = _a + _b * n_r;     //ascissa del punto medio di ciascun intervallino
        _sum += _integrand->eval(x);    // sommo i valori di f --> integrale = [f(x1)+f(x2)+...+f(xn)]*h
    }
    _integral=_sign*_sum*_h;
    return _integral;
}

double integral::midPointMCF_2 (int i_rnd) {
    _sum=0.;
    _rnd.Random_std(&_rnd);
    int _i_rnd=i_rnd;
    _h= (_b-_a)/_i_rnd;
    for (int i=0; i<_i_rnd; i++) {
        double R = _rnd.Rannyu();
        double n_r=1-sqrt(1.- (R)*8/pow(M_PI,2))+1;
        double x = _a + _b * n_r;     //ascissa del punto medio di ciascun intervallino
        _sum += _integrand->eval(x);    // sommo i valori di f --> integrale = [f(x1)+f(x2)+...+f(xn)]*h
    }
    _integral=_sign*_sum*_h;
    return _integral;
}
