#include <iostream>
#include <iomanip>
#include <cmath>
#include "funzioni.h"
#include "random.h"
#include "integrali.h"
using namespace std;

int sign (double x){
	if (x<0) return -1;
	else return 1;
}

parabola::parabola (){
	_a=0;
	_b=0;
	_c=0;
}

parabola::parabola (double a, double b, double c){
	_a=a;
	_b=b;
	_c=c;
}

double parabola::eval (double x) const {
	return _a*pow(x,2)+_b*x+_c; 
}

retta::retta (){
    _m=0;
    _q=0;
}

retta::retta (double m, double q){
    _m=m;
    _q=q;
}

double retta::eval (double x) const {
    return _m*x+_q;
}

cos1::cos1 (){
   // _a=0;
    //_b=0;
}

double cos1::eval (double x) const {
    return M_PI*0.5*cos(M_PI*0.5*x);
}
cos2::cos2 (){
}


double cos2::eval (double x) const {
    return M_PI*0.5*cos(M_PI*0.5*x)/(M_PI*M_PI*0.25-x*M_PI*M_PI*0.25);
}

/*
N_x::N_x (){}


double N_x::eval (double x) const {
    return 2./M_PI*
}

e_z::e_z (){}

e_z::eval (double x){
    return exp(-x*x)
}
*/
e_z::e_z (){}

double e_z::eval (double x) const {
    return exp(-x*x);
}

d1_d2::d1_d2 (){
    double _sigma=0;
    double _T=0;
    double _K=0;
    double _r=0;
}


d1_d2::d1_d2 (double sigma, double T, double K, double r){
    _sigma=sigma;
    _T=T;
    _K=K;
    _r=r;
}


 double d1_d2::eval_d1 (double S, double t) const {

    return 1./(_sigma*sqrt(_T-t))*(log(S/_K)+(_r+_sigma*_sigma/2*(_T-t)));
}
double d1_d2::eval_d2( double t, double d1) const {
    return d1-_sigma*sqrt(_T-t);
}

N_X::N_X (){

}

double N_X::eval (double x, funzioneBase*f){
    integral integrale(0, x/sqrt(2), f);
    
    return 0.5+(1./sqrt(M_PI))*integrale.midPointMCU(10000);

}


CP_european::CP_european (){};
//CP_european::CP_european (){};

double CP_european::evalC (double S, double N1, double N2, double K, double r, double T,double t) {
    double C_ = S*N1-K*exp(-r*(T-t))*N2;
    return C_;
}
double CP_european::evalP (double S, double N1, double N2, double K, double r, double T,double t) {
    double P_= S*(N1-1)-K*exp(-r*(T-t))*(N2-1);
    return P_;
}

