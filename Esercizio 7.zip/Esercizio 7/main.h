
#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <cstring>
#include <iostream>
using namespace std;


double dev_std(double * vettore, int ind)





