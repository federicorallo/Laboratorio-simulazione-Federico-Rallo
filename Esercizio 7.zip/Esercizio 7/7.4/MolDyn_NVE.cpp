 /****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
#include <stdlib.h>     // srand, rand: to generate random number
#include <iostream>     // cin, cout: Standard Input/Output Streams Library
#include <fstream>      // Stream class to both read and write from/to files.
#include <cmath>        // rint, pow
#include "MolDyn_NVE.h"
#include "blocchi.h"

using namespace std;

int main(){
    int nblk = 10;
    cout<<"enter the number of simulation that you want to run. If it's the first time the program runs type 1"<<endl;
    int simulazioni=1;
    cin>>simulazioni;
    

    for(int s__=0;s__<simulazioni;s__++){
    
    for (int ciclo=0; ciclo<3; ciclo++){
        contatore = 0;
        Input(ciclo);             //Inizialization
  int nconf = 1;
      for(int iblk=1; iblk <= nblk; ++iblk){ //Simulation
          Reset(iblk);   //Reset block averages

          for(int istep=1; istep <= nstep; ++istep){
              Move();           //Move particles with Verlet algorithm
              Accumulate(); //Update block averages

              if(istep%iprint == 0) cout << "Number of time-steps: " << istep << endl;
              if(istep%10 == 0){
                  Measure(ciclo);
                  nconf += 1;
              }
          }
          Averages(iblk, ciclo);   //Print results for current block
        Gavefinal(ciclo);
      }
        ConfFinal(ciclo);         //Write final configuration to restart

   }



    /*
    //faccio le medie
    blocchi medie(lenght, nblocks);
      medie.do_it(v_temp);
    
      for (int i=0; i<nblocks;i++){
          av_temp[i]=medie.get(i);
          er_temp[i]=medie.get_error(i);
          cout<<av_temp[i]<<" +-  "<< er_temp[i]<<endl;
      }
    if (ciclo==0) medie.stampa("av_temp.dat");
    if (ciclo==1) medie.stampa("av_temp_liquid.dat");
    if (ciclo==2) medie.stampa("av_temp_solid.dat");
    
    
      medie.do_it(v_kin);
    
      for (int i=0; i<nblocks;i++){
          av_kin[i]=medie.get(i);
          er_kin[i]=medie.get_error(i);
      }
      if (ciclo==0) medie.stampa("av_kin.dat");
      if (ciclo==1) medie.stampa("av_kin_liquid.dat");
      if (ciclo==2) medie.stampa("av_kin_solid.dat");

      medie.do_it(v_pot);
    
      for (int i=0; i<nblocks;i++){
          av_pot[i]=medie.get(i);
          er_pot[i]=medie.get_error(i);
      }
      if (ciclo==0) medie.stampa("av_pot.dat");
      if (ciclo==1) medie.stampa("av_pot_liquid.dat");
      if (ciclo==2) medie.stampa("av_pot_solid.dat");

        medie.do_it(v_tot);
    
      for (int i=0; i<nblocks;i++){
          av_tot[i]=medie.get(i);
          er_tot[i]=medie.get_error(i);
      }
       if (ciclo==0) medie.stampa("av_tot.dat");
       if (ciclo==1) medie.stampa("av_tot_liquid.dat");
       if (ciclo==2) medie.stampa("av_tot_solid.dat");
     
     */
    }
    
  return 0;
}


void Input(int  ciclo){ //Prepare all stuff for the simulation
  ifstream ReadInput,ReadConf, ReadOld;
  double ep, ek, pr, et, vir;
    
    
    
    
    if(ciclo==0) cout<< "if you want to read config.0 type 0. Else type 1 and the previous configuration config.final will be read"<<endl;
    if (ciclo==0) cin>>start_;
    cout<<endl;
    
    

  cout << "Classic Lennard-Jones fluid        " << endl;
  cout << "Molecular dynamics simulation in NVE ensemble  " << endl << endl;
  cout << "Interatomic potential v(r) = 4 * [(1/r)^12 - (1/r)^6]" << endl << endl;
  cout << "The program uses Lennard-Jones units " << endl;

  seed = 1;    //Set seed for random numbers
  srand(seed); //Initialize random number generator
  
    if (ciclo == 0){
  ReadInput.open("input.dat"); //Read input
    }
    if(ciclo== 1){
        ReadInput.open("input.liquid"); //Read input

    }
    if(ciclo== 2){
        ReadInput.open("input.solid"); //Read input

    }
    
    

  ReadInput >> temp;

  ReadInput >> npart;
  cout << "Number of particles = " << npart << endl;

  ReadInput >> rho;
  cout << "Density of particles = " << rho << endl;
  vol = (double)npart/rho;
  cout << "Volume of the simulation box = " << vol << endl;
  box = pow(vol,1.0/3.0);
  cout << "Edge of the simulation box = " << box << endl;

  ReadInput >> rcut;
  ReadInput >> delta;
  ReadInput >> nstep;
  ReadInput >> iprint;

  cout << "The program integrates Newton equations with the Verlet method " << endl;
  cout << "Time step = " << delta << endl;
  cout << "Number of steps = " << nstep << endl << endl;
  ReadInput.close();

//Prepare array for measurements
  iv = 0; //Potential energy
  iw = 0;
  /*ik = 1; //Kinetic energy
  ie = 2; //Total energy
  it = 3; //Temperature
  n_props = 4; //Number of observables*/
    
  igofr = 2;
  nbins = 100;
  n_props = igofr + nbins;
  bin_size = (box/2.0)/(double)nbins;
    
    walker = new double [n_props];
    glob_av=new double [n_props];
    glob_av2=new double [n_props];
    blk_av=new double [n_props];
    
    
    /*
    // inizializzo ciò che mi serve per le medie
    int L=10;
    lenght = nstep/10;
    nblocks = 100;
    
    v_temp = new double[lenght];
    v_kin = new double[lenght];
    v_tot = new double[lenght];
    v_pot = new double[lenght];
    
    av_temp = new double[nblocks];
    av_kin = new double[nblocks];
    av_tot = new double[nblocks];
    av_pot = new double[nblocks];
    
    er_temp = new double[nblocks];
    er_kin = new double[nblocks];
    er_tot = new double[nblocks];
    er_pot = new double[nblocks];
    */

    //------------------------
    
    if(start_==0){
//Read initial configuration
  cout << "Read initial configuration from file config.0 " << endl << endl;
  ReadConf.open("config.0");
        
  for (int i=0; i<npart; ++i){
    ReadConf >> x[i] >> y[i] >> z[i];
    x[i] = x[i] * box;
    y[i] = y[i] * box;
    z[i] = z[i] * box;
  }
  ReadConf.close();

//Prepare initial velocities
   cout << "Prepare random velocities with center of mass velocity equal to zero " << endl << endl;
   double sumv[3] = {0.0, 0.0, 0.0};
   for (int i=0; i<npart; ++i){
     vx[i] = rand()/double(RAND_MAX) - 0.5;
     vy[i] = rand()/double(RAND_MAX) - 0.5;
     vz[i] = rand()/double(RAND_MAX) - 0.5;

     sumv[0] += vx[i];
     sumv[1] += vy[i];
     sumv[2] += vz[i];
   }
   for (int idim=0; idim<3; ++idim) sumv[idim] /= (double)npart;
   double sumv2 = 0.0, fs;
   for (int i=0; i<npart; ++i){
     vx[i] = vx[i] - sumv[0];
     vy[i] = vy[i] - sumv[1];
     vz[i] = vz[i] - sumv[2];

     sumv2 += vx[i]*vx[i] + vy[i]*vy[i] + vz[i]*vz[i];
   }
   sumv2 /= (double)npart;

   fs = sqrt(3 * temp / sumv2);   // fs = velocity scale factor 
   for (int i=0; i<npart; ++i){
     vx[i] *= fs;
     vy[i] *= fs;
     vz[i] *= fs;

     xold[i] = Pbc(x[i] - vx[i] * delta);
     yold[i] = Pbc(y[i] - vy[i] * delta);
     zold[i] = Pbc(z[i] - vz[i] * delta);
   }
    }
    //-----------------------------------
    
    if (start_!=0){
        

          cout << "Read initial configuration from file config.final " << endl << endl;

          ifstream readinput, readinputold;
        if(ciclo==0){
          readinput.open("config.final");
          readinputold.open("old.final");
        }
        if(ciclo==1){
          readinput.open("config1.final");
          readinputold.open("old1.final");
        }
        if (ciclo==2){
          readinput.open("config2.final");
          readinputold.open("old2.final");
        }
        
          for(int i=0;i<npart;i++){
              
              readinput>>x[i]>>y[i]>>z[i];
              readinputold>>xold[i]>>yold[i]>>zold[i];
              
              x[i]=x[i]*box;
              y[i]=y[i]*box;
              z[i]=z[i]*box;
              xold[i]=xold[i]*box;
              yold[i]=yold[i]*box;
              zold[i]=zold[i]*box;
          }
          readinput.close();
          readinputold.close();
          
          Move();
          
          double sumv2=0.;
          for(int i=0;i<npart;i++){
              vx[i]=Pbc(x[i]-xold[i])/(delta);
              vy[i]=Pbc(y[i]-yold[i])/(delta);
              vz[i]=Pbc(z[i]-zold[i])/(delta);
              sumv2+=pow(vx[i],2.)+pow(vy[i],2.)+pow(vz[i],2.);
          }
          
          sumv2/=double(npart);
          cout<<"sumv2: "<<sumv2<<endl;
          double T_=sumv2/3.;
          double fs=sqrt(temp/T_);
          for(int i=0;i<npart;i++){
              vx[i]*=fs;
              vy[i]*=fs;
              vz[i]*=fs;
              xold[i]=Pbc(x[i]- delta*vx[i]);
              yold[i]=Pbc(y[i]-delta*vy[i]);
              zold[i]=Pbc(z[i]-delta*vz[i]);
          }

        
        
    }
    
    
   return;
}


void Move(void){ //Move particles with Verlet algorithm
  double xnew, ynew, znew, fx[m_part], fy[m_part], fz[m_part];

  for(int i=0; i<npart; ++i){ //Force acting on particle i
    fx[i] = Force(i,0);
    fy[i] = Force(i,1);
    fz[i] = Force(i,2);
  }

  for(int i=0; i<npart; ++i){ //Verlet integration scheme

    xnew = Pbc( 2.0 * x[i] - xold[i] + fx[i] * pow(delta,2) );
    ynew = Pbc( 2.0 * y[i] - yold[i] + fy[i] * pow(delta,2) );
    znew = Pbc( 2.0 * z[i] - zold[i] + fz[i] * pow(delta,2) );

    vx[i] = Pbc(xnew - xold[i])/(2.0 * delta);
    vy[i] = Pbc(ynew - yold[i])/(2.0 * delta);
    vz[i] = Pbc(znew - zold[i])/(2.0 * delta);

    xold[i] = x[i];
    yold[i] = y[i];
    zold[i] = z[i];

    x[i] = xnew;
    y[i] = ynew;
    z[i] = znew;
  }
  return;
}

double Force(int ip, int idir){ //Compute forces as -Grad_ip V(r)
  double f=0.0;
  double dvec[3], dr;

  for (int i=0; i<npart; ++i){
    if(i != ip){
      dvec[0] = Pbc( x[ip] - x[i] );  // distance ip-i in pbc
      dvec[1] = Pbc( y[ip] - y[i] );
      dvec[2] = Pbc( z[ip] - z[i] );

      dr = dvec[0]*dvec[0] + dvec[1]*dvec[1] + dvec[2]*dvec[2];
      dr = sqrt(dr);

      if(dr < rcut){
        f += dvec[idir] * (48.0/pow(dr,14) - 24.0/pow(dr,8)); // -Grad_ip V(r)
      }
    }
  }
  
  return f;
}

void Measure(int ciclo){ //Properties measurement
  int bin;
  double v, t, vij, w, wij;
  double dx, dy, dz, dr;
  ofstream Epot, Ekin, Etot, Temp, Pres, Pot;
/*
    if (ciclo ==0){
  Epot.open("output_epot.dat",ios::app);
  Ekin.open("output_ekin.dat",ios::app);
  Temp.open("output_temp.dat",ios::app);
  Etot.open("output_etot.dat",ios::app);
    }
    if (ciclo ==1){
    Epot.open("output_epot1.dat",ios::app);
    Ekin.open("output_ekin1.dat",ios::app);
    Temp.open("output_temp1.dat",ios::app);
    Etot.open("output_etot1.dat",ios::app);
      }
    if (ciclo ==2){
    Epot.open("output_epot2.dat",ios::app);
    Ekin.open("output_ekin2.dat",ios::app);
    Temp.open("output_temp2.dat",ios::app);
    Etot.open("output_etot2.dat",ios::app);
      }
    */
  v = 0.0; //reset observables
  w = 0.0;
  t = 0.0;

//cycle over pairs of particles
  for (int i=0; i<npart-1; ++i){
    for (int j=i+1; j<npart; ++j){

     dx = Pbc( xold[i] - xold[j] ); // here I use old configurations [old = r(t)]
     dy = Pbc( yold[i] - yold[j] ); // to be compatible with EKin which uses v(t)
     dz = Pbc( zold[i] - zold[j] ); // => EPot should be computed with r(t)

     dr = dx*dx + dy*dy + dz*dz;
     dr = sqrt(dr);
     
        
        
          if(dr<=box*0.5){
              bin=0;
              for(float l=0;l+bin_size<dr;l+=bin_size){
                  bin++;
              }
          //bin=int(dr/bin_size);
          walker[igofr+bin]+=2;
          }
             
     //update of the histogram of g(r)

          if(dr < rcut)
          {
            vij = 1.0/pow(dr,12) - 1.0/pow(dr,6);
            wij = 1.0/pow(dr,12) - 0.5/pow(dr,6);

     // contribution to energy and virial
            v += vij;
            w += wij;
          }
         }
       }

    walker[iv] = 4.0 * v;
    walker[iw] = 48.0 * w / 3.0;
    
//Kinetic energy
  for (int i=0; i<npart; ++i) t += 0.5 * (vx[i]*vx[i] + vy[i]*vy[i] + vz[i]*vz[i]);
   
    if (ciclo==0){
    Pres.open("pres_gas.instant",ios::app);
    Pot.open("pot_gas.instant",ios::app);
    }
    if (ciclo==1){
    Pres.open("pres_liquid.instant",ios::app);
    Pot.open("pot_liquid.instant",ios::app);
    }
    if(ciclo==2){
    Pres.open("pres_solid.instant",ios::app);
    Pot.open("pot_solid.instant",ios::app);
    }
    
    Pres << rho * temp + (walker[iw]+ptail*npart) / vol  << endl;
    //Pressure
    Pot << (walker[iv]/npart + vtail) << endl;
    
    Pres.close();
    Pot.close();
    
    
    return;
}

void Reset(int iblk) //Reset block averages
{
   
   if(iblk == 1)
   {
       for(int i=0; i<n_props; ++i)
       {
           glob_av[i] = 0;
           glob_av2[i] = 0;
       }
   }

   for(int i=0; i<n_props; ++i)
   {
     blk_av[i] = 0;
   }
   blk_norm = 0;
   attempted = 0;
   accepted = 0;
}

void Accumulate(void) //Update block averages
{

   for(int i=0; i<n_props; ++i)
   {
     blk_av[i] = blk_av[i] + walker[i];
   }
   blk_norm = blk_norm + 1.0;
}



void Averages(int iblk, int big_counter) //Print results for current block

//ho incluso il calcolo di gdir e gdir finale. gdir finale viene calcolato facendo la media tra le medie finali dei blocchi di gdir.
//
{
    
   double r, gdir;
   ofstream Gofr, Gave, Epot, Pres;
   const int wd=12;
    
    cout << "Block number " << iblk << endl;
    cout << "Acceptance rate " << accepted/attempted << endl << endl;
    if(big_counter==0){
    Epot.open("output_gas.epot.0",ios::app);
    Pres.open("output_gas.pres.0",ios::app);
    Gofr.open("output_gas.gofr.0",ios::app);
            //if(iblk == nblk){
    //Gave.open("output_gas.gave.0",ios::app);
            //}
    }
    if(big_counter==1){
    Epot.open("output_liquid.epot.0",ios::app);
    Pres.open("output_liquid.pres.0",ios::app);
    Gofr.open("output_liquid.gofr.0",ios::app);
            /*if(iblk == nblk){
    //Gave.open("output_liquid.gave.0",ios::app);
            }*/
    }
    if(big_counter==2){
    Epot.open("output_solid.epot.0",ios::app);
    Pres.open("output_solid.pres.0",ios::app);
    Gofr.open("output_solid.gofr.0",ios::app);
           /* if(iblk == nblk){
    Gave.open("output_solid.gave.0",ios::app);
            }*/
    }
    
    
    stima_pot = blk_av[iv]/blk_norm/(double)npart + vtail; //Potential energy
    glob_av[iv] += stima_pot;
    glob_av2[iv] += stima_pot*stima_pot;
    err_pot=Error(glob_av[iv],glob_av2[iv],iblk);
    
    stima_pres = rho * temp + (blk_av[iw]/blk_norm + ptail * (double)npart) / vol; //Pressure
    glob_av[iw] += stima_pres;
    glob_av2[iw] += stima_pres*stima_pres;
    err_press=Error(glob_av[iw],glob_av2[iw],iblk);

    //calcolo di gdir
    Gofr<<iblk<<"   ";
    for(int i=0;i<nbins;i++){
        double norm=0.;
        r=i*bin_size;
        norm=rho*npart*(4*M_PI*(pow(r+bin_size,3.)-pow(r,3.)))/3.;
        gdir=blk_av[igofr+i]/blk_norm/100./norm;
        glob_av[igofr+i]+=gdir;
        glob_av2[igofr+i]+=gdir*gdir;
        Gofr<<gdir<<" ";
    }

    Gofr<<endl;
    cout<<endl;

    
//Potential energy per particle
    Epot << setw(wd) << iblk <<  setw(wd) << stima_pot << setw(wd) << glob_av[iv]/(double)iblk << setw(wd) << err_pot << endl;
//Pressure
    Pres << setw(wd) << iblk <<  setw(wd) << stima_pres << setw(wd) << glob_av[iw]/(double)iblk << setw(wd) << err_press << endl;

    cout <<endl<< "----------------------------" << endl << endl;

    Epot.close();
    Pres.close();
    Gofr.close();
    
   /* //stampo gdir finale
        if(iblk == nblk){
            for(int zz=2; zz++;zz<101){
                Gave<<(zz-2)*bin_size<< glob_av[zz]/nblk << setw(wd) << Error(glob_av[zz], glob_av2[zz], iblk)<<endl;
            }
            Gave.close();

        }*/

}




void ConfFinal(int ciclo){ //Write final configuration
  ofstream WriteConf, WriteOld;

  cout << "Print final configuration to file config.final " << endl << endl;
    
    if (ciclo ==0){
        WriteConf.open("config.final");}
    if (ciclo ==1){
        WriteConf.open("config1.final");}
    if (ciclo ==2){
        WriteConf.open("config2.final");}

        
        
  for (int i=0; i<npart; ++i){
    WriteConf << x[i]/box << "   " <<  y[i]/box << "   " << z[i]/box << endl;
  }
  WriteConf.close();
    if(ciclo==0){
        WriteOld.open("old.final");}
    if(ciclo==1){
        WriteOld.open("old1.final");}
    if(ciclo==2){
        WriteOld.open("old2.final");}
    
    for (int i=0; i<npart; ++i){
      WriteOld << xold[i]/box << "   " <<  yold[i]/box << "   " << zold[i]/box << endl;
    }
    WriteOld.close();
    
  return;
}
    

         


void ConfXYZ(int nconf){ //Write configuration in .xyz format
  ofstream WriteXYZ;

  WriteXYZ.open("frames/config_" + to_string(nconf) + ".xyz");
  WriteXYZ << npart << endl;
  WriteXYZ << "This is only a comment!" << endl;
  for (int i=0; i<npart; ++i){
    WriteXYZ << "LJ  " << Pbc(x[i]) << "   " <<  Pbc(y[i]) << "   " << Pbc(z[i]) << endl;
  }
  WriteXYZ.close();
}

double Pbc(double r){  //Algorithm for periodic boundary conditions with side L=box
    return r - box * rint(r/box);
}



double Error(double sum, double sum2, int iblk)
{
    if( iblk == 1 ) return 0.0;
    else return sqrt((sum2/(double)iblk - pow(sum/(double)iblk,2))/(double)(iblk-1));
}

void Gavefinal(int big_counter){
    ofstream Gave;
    if (big_counter ==0){
    Gave.open("output.gave.gas.0",ios::app);
    }
    if (big_counter ==1){
    Gave.open("output.gave.liquid.0",ios::app);
    }
    if (big_counter ==2){
    Gave.open("output.gave.solid.0",ios::app);
    }
    
    
    double err=0,r=0;
    for(int i=0;i<nbins;i++){
        r=i*bin_size;
        
        //cout<<glob_av[igofr+i]/10.<<"porcodio"<<glob_av2[igofr+i]<<endl;
        err=Error(glob_av[igofr+i],glob_av2[igofr+i],nblk);
        Gave<<r<<" "<<glob_av[igofr+i]/10.<<" "<<err<<endl;
        cout<<glob_av[igofr+i]/10.<<endl;
    }
    Gave.close();
}

/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
