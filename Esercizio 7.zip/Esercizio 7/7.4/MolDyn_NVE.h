/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
//parameters, observables
const int m_props=4;

int iv,ik,it,ie,iw;
double stima_kin, stima_etot, stima_temp, nblk;

double*istogramma0=new double[100];
double*istogramma1=new double[100];
double*istogramma2=new double[100];

// averages
double acc,att;
int n_props;
//configuration
const int m_part=108;
double x[m_part],y[m_part],z[m_part],xold[m_part],yold[m_part],zold[m_part];
double vx[m_part],vy[m_part],vz[m_part];

// thermodynamical state
int npart;
double energy,temp,vol,rho,box,rcut;

//medie
double *v_pot, *v_kin, *v_temp, *v_tot;
double *er_pot, *er_kin, *er_temp, *er_tot;
double *av_pot, *av_kin, *av_temp, *av_tot;

int nblocks, lenght, contatore;

int ciclo;
double start_;

// simulation
int nstep, iprint, seed;
double delta;
double *walker;


int igofr;
double vtail,ptail,bin_size,nbins,sd;


//functions
void Input(int);
void Move(void);
void ConfFinal(int);
void ConfXYZ(int);
void Measure(int);
double Force(int, int);
double Pbc(double);

double Error(double,double,int);
void Reset(int);
void Accumulate(void);
void Averages(int,int);
void Gavefinal(int);

double *blk_av;
double blk_norm,accepted,attempted;
double *glob_av;
double *glob_av2;
double stima_pot,stima_pres,err_pot,err_press,err_gdir;
double final_gdir[100];
double final_gdir2[100];
const double pi=3.1415927;


/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
