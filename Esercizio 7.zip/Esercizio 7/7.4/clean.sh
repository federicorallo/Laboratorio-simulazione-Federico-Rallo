rm -rf *epot*
rm -rf *ekin*
rm -rf *etot*
rm -rf *temp*
rm -rf frames/*.xyz
