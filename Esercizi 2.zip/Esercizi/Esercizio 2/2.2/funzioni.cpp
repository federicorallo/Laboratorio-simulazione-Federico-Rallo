#include <iostream>
#include <iomanip>
#include <cmath>
#include "funzioni.h"

using namespace std;

int sign (double x){
	if (x<0) return -1;
	else return 1;
}

parabola::parabola (){
	_a=0;
	_b=0;
	_c=0;
}

parabola::parabola (double a, double b, double c){
	_a=a;
	_b=b;
	_c=c;
}

double parabola::eval (double x) const {
	return _a*pow(x,2)+_b*x+_c; 
}

retta::retta (){
    _m=0;
    _q=0;
}

retta::retta (double m, double q){
    _m=m;
    _q=q;
}

double retta::eval (double x) const {
    return _m*x+_q;
}

cos1::cos1 (){
   // _a=0;
    //_b=0;
}

double cos1::eval (double x) const {
    return M_PI*0.5*cos(M_PI*0.5*x);
}
cos2::cos2 (){
}


double cos2::eval (double x) const {
    return M_PI*0.5*cos(M_PI*0.5*x)/(M_PI*M_PI*0.25-x*M_PI*M_PI*0.25);
}


