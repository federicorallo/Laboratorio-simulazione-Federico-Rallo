#ifndef _INTEGRALI_H_
#define _INTEGRALI_H_

using namespace std;

#include "funzioni.h"
#include "random.h"

class integral {
public:
    //costruttori
    integral () {_sign=0; _a=0; _b=0; _integral=0; _nSteps=2; _precision=100;} //se mi "dimentico" di implementare comunque l'integrale fara' zero -> non faccio troppi danni...
    
	integral (double a, double b, funzioneBase * f); //inizializza automaticamente _nSteps e _precision a valori ragionevoli se poi li usassi
    integral (double a, double b, funzioneBase * f, int nSteps); //inizializza comunque automaticamente _precision a valore ragionevole
    integral (double a, double b, funzioneBase * f, double precision); //inizializza comunque automaticamente _nSteps a valore ragionevole

    //recupero datamembri
	double a () {return _a;}
	double b () {return _b;}
	double nSteps () {return _nSteps;}
    double precision () {return _precision;}
	double integralValue () {return _integral;}
	
    //impostazione datamembri
    void setA (double a); //controlla se è <b e nel caso cambia il segno
    void setB (double b); //controlla se è >a e nel caso cambia il segno
	void setSteps (int n) {_nSteps=n;}
    void setPrecision (double prec) {_precision=prec;}
	void setFunction (funzioneBase * f) {_integrand=f;}

    
    //metodi per calcolo integrale
	
    double midPoint (int nSteps);
    double midPoint () {return midPoint (_nSteps);}//overloading che usa nSteps immagazzinato nella classe
    
    double midPointMCU (int i_rnd, double*vettore);

    double midPointMCF (int i_rnd, double*vettore);
    
    double midPointMCU_2 (int i_rnd, double*vettore);

    double midPointMCF_2 (int i_rnd, double*vettore);

    
	
    double simpson (int nSteps);
    double simpson () {return simpson (_nSteps);}//overloading che usa nSteps immagazzinato nella classe

protected:
	double _a,_b, _precision;
	int _nSteps;
	double _integral;
	funzioneBase * _integrand;
private:
	double _sum;
	double _h;
    int _sign;
    Random _rnd;
};









#endif
