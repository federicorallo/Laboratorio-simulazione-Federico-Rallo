//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;
#include "blocchi.h"
#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "funzioni.h"
#include "integrali.h"


int main(){
    
    Random rnd;
    rnd.Random_std(&rnd);
    
    double*C_k=new double [10000];
    double*P_k=new double [10000];
    
    double*C_kd=new double [10000];
    double*P_kd=new double [10000];
    
    blocchi CCC(10000,100);
    blocchi PPP(10000,100);
    blocchi CCC2(10000,100);
    blocchi PPP2(10000,100);
    
    double*S=new double [100];
    S[0]=100.;
    double*av_S=new double [100];
    for (int i=0;i<100;i++) av_S[i]=0;
    av_S[0]=100;
    
    double T=1.;
    double passo = 0.01;
    double K=100;
    double r=0.1;
    double sigma=0.25;
    double t=0;
    
    d1_d2 D(sigma, T, K, r);
    d1_d2 D2(sigma, T, K, r);

    N_X N_;
    N_X N_2;

    funzioneBase*ez= new e_z();
    CP_european cp;
    CP_european cp2;
    //calcolo per S0
    for (int k=0; k<10000;k++){
        double z = rnd.Gauss(0,1);
        double S__ = S[0] * exp((r-sigma*sigma/2) + sigma*z);
        double C = exp(-r*T) * max (S__ - K,0.);
        double P = exp(-r*T) * max (-S__ + K,0.);
        C_kd[k]=C;
        P_kd[k]=P;
        //cout<<"   "<< + double(k)/200.<<"%"<<endl;
        //cout<<C<<endl;
    }
    
    //CALCOLO S[100] DIECIMILA VOLTE
    for (int k=0; k<10000; k++){
        S[0]=100.;
        for(int i=0; i<99;i++){
            double z = rnd.Gauss(0.,1.);
            S[i+1] = S[i] * exp((r-sigma*sigma/2)*0.01+sigma*(z)*sqrt(0.01));
        }
        
        
        
        double d1 = D2.eval_d1(S[99], 0);
        double d2 = D2.eval_d2(0, d1);
        double N1 = N_2.eval(d1, ez);
        double N2 = N_2.eval(d2, ez);
        C_k[k] = exp(-r*T) * max (S[99] - K,0.);
        P_k[k] = exp(-r*T) * max (-S[99] + K,0.);
        //cout<<"   "<< 50 + double(k)/200.<<"%"<<endl;


    }
    
    CCC.do_it(C_kd);
    CCC.stampa("Call.dat");
    CCC2.do_it(C_k);
    CCC2.stampa("Call_t.dat");
    
    PPP.do_it(P_kd);
    PPP.stampa("Put.dat");
    PPP2.do_it(P_k);
    PPP2.stampa("Put_t.dat");
    
    /*
    ofstream Output;
    Output.open("C_P.dat");
    for (int i=0; i<10000; i++){
        Output<<C_k[i]<<"   "<<P_k[i]<<endl;
    }
    Output.close();
    //cout<<endl<<C<< "   "<<P<<endl<<endl;
    */
    
    return 0;
}
