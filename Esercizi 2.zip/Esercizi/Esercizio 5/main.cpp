//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "blocchi.h"


//raggio di bohr
double a0=1;
//ground state

double P_1(double x, double y, double z){
    double r = sqrt(x*x+y*y+z*z);
    double p = pow(a0, -3)*exp(-2*r/a0)/M_PI;
    return p;
}

//primo stato eccitato
double P_2(double x, double y, double z){
    double r = sqrt(x*x+y*y+z*z);
    double p = pow(a0, -5)*exp(-r/a0)*z*z/(32*M_PI);
    return p;
}

int main(){
    
    Random rnd;
    rnd.Random_std(&rnd);
    int M=100000;
    double*x = new double[3];
    double*xnew = new double[3];
    double*r = new double[M];
    double delta = 1.332;
    int nacc= 0;
    double*X = new double[M];
    double*Y = new double[M];
    double*Z = new double[M];
    ofstream coordinate;
    
    blocchi uni_P1(M,100);
    
    //come posizione iniziale uso il raggio medio
// ground state uni
    for (int j=0; j<M;j++){
        if(j%1000==0) cout<<j/4000<<"%"<<endl;
        x[0]=0.865;
        x[1]=0.865;
        x[2]=0.865;
    
        for(int i=0; i<1000; i++){
            xnew[0]=rnd.Rannyu(x[0]-delta, x[0]+delta);
            xnew[1]=rnd.Rannyu(x[1]-delta, x[1]+delta);
            xnew[2]=rnd.Rannyu(x[2]-delta, x[2]+delta);

            double a=min(1., P_1(xnew[0], xnew[1], xnew[2])/P_1(x[0], x[1], x[2]));
            
            //accetto
            if(rnd.Rannyu() <= a){
                x[0]=xnew[0];
                x[1]=xnew[1];
                x[2]=xnew[2];
            }
            //se no rifiuto e lascio tutto invariato
        }
    r[j]=sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);
        X[j] = x[0];
        Y[j] = x[1];
        Z[j] = x[2];
    }
    
    uni_P1.do_it(r);
    uni_P1.stampa("<r0>_uni");

    coordinate.open("P0_uni");
    for(int i=0; i<M;i++) coordinate<<X[i]<<"   "<<Y[i]<<"  "<<Z[i]<<endl;
    coordinate.close();
    
    delta=1.13;
 
 // ground state gauss
    
    for (int j=0; j<M;j++){
        if(j%1000==0) cout<<25 + j/4000<<"%"<<endl;
        x[0]=0.865;
        x[1]=0.865;
        x[2]=0.865;
    
        for(int i=0; i<1000; i++){
            xnew[0]=rnd.Gauss(x[0], delta);
            xnew[1]=rnd.Gauss(x[1], delta);
            xnew[2]=rnd.Gauss(x[2], delta);

            double a=min(1., P_1(xnew[0], xnew[1], xnew[2])/P_1(x[0], x[1], x[2]));
            
            //accetto
            if(rnd.Rannyu() <= a){
                x[0]=xnew[0];
                x[1]=xnew[1];
                x[2]=xnew[2];
                nacc++;
            }
            
            //se no rifiuto e lascio tutto invariato
        }
    r[j]=sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);
        X[j] = x[0];
        Y[j] = x[1];
        Z[j] = x[2];
    }
    uni_P1.do_it(r);
    uni_P1.stampa("<r0>_gauss");

    coordinate.open("P0_gauss");
    for(int i=0; i<M;i++) coordinate<<X[i]<<"   "<<Y[i]<<"  "<<Z[i]<<endl;
    coordinate.close();
    
    
    // primo stato eccitato uni
    double delta_p2= 2.373;
    
    for (int j=0; j<M;j++){
        if(j%1000==0) cout<<50 + j/4000<<"%"<<endl;
        x[0]=0.865;
        x[1]=0.865;
        x[2]=0.865;
    
        for(int i=0; i<1000; i++){
            xnew[0]=rnd.Rannyu(x[0]-delta_p2, x[0]+delta_p2);
            xnew[1]=rnd.Rannyu(x[1]-delta_p2, x[1]+delta_p2);
            xnew[2]=rnd.Rannyu(x[2]-delta_p2, x[2]+delta_p2);

            double a=min(1., P_2(xnew[0], xnew[1], xnew[2])/P_2(x[0], x[1], x[2]));
            
            //accetto
            if(rnd.Rannyu() <= a){
                x[0]=xnew[0];
                x[1]=xnew[1];
                x[2]=xnew[2];
            }
            //se no rifiuto e lascio tutto invariato
        }
    r[j]=sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);
        X[j] = x[0];
        Y[j] = x[1];
        Z[j] = x[2];
    }
    uni_P1.do_it(r);
    uni_P1.stampa("<r1>_uni");
    
    coordinate.open("P1_uni");
    for(int i=0; i<M;i++) coordinate<<X[i]<<"   "<<Y[i]<<"  "<<Z[i]<<endl;
    coordinate.close();
    
    delta_p2=1.541;//gauss p2!!!

    
    for (int j=0; j<M;j++){
        if(j%1000==0) cout<<75 + j/4000<<"%"<<endl;
        x[0]=0.865;
        x[1]=0.865;
        x[2]=0.865;
    
        for(int i=0; i<1000; i++){
            xnew[0]=rnd.Gauss(x[0], delta_p2);
            xnew[1]=rnd.Gauss(x[1], delta_p2);
            xnew[2]=rnd.Gauss(x[2], delta_p2);

            double a=min(1., P_2(xnew[0], xnew[1], xnew[2])/P_2(x[0], x[1], x[2]));
            
            //accetto
            if(rnd.Rannyu() <= a){
                x[0]=xnew[0];
                x[1]=xnew[1];
                x[2]=xnew[2];
            }
            
            //se no rifiuto e lascio tutto invariato
        }
    r[j]=sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);
        X[j] = x[0];
        Y[j] = x[1];
        Z[j] = x[2];
    }
    uni_P1.do_it(r);
    uni_P1.stampa("<r1>_gauss");
    
    coordinate.open("P1_gauss");
    for(int i=0; i<M;i++) coordinate<<X[i]<<"   "<<Y[i]<<"  "<<Z[i]<<endl;
    coordinate.close();
    
    
    
    
    
    return 0;
}
