
#ifndef _BLOCCHI_H_
#define _BLOCCHI_H_

using namespace std;
#include <iostream>
#include <cstring>
#include <fstream>


class blocchi {
public:
    //costruttori
    blocchi ();
    
	blocchi (int dimensione, int blocchi);


    void do_it (double * vettore);

    double get_error(int indice);
    double get(int indice);
    void stampa(string nomefile);
    
protected:
    int dimensione_; int blocchi_; int dim_blocchi;
    double *vettore_media, *vettore_errori;
    ofstream ostampa;
    double * av_progress;
};









#endif
