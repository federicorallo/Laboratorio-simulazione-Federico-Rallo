//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "blocchi.h"


//raggio di bohr

//ground state

double P(double x, double sigma, double mu){
    double p = pow(exp(-pow((x-mu),2)/(2*sigma*sigma))+exp(-pow(x+mu,2)/(2*sigma*sigma)),2);
    return p;
}

double Psi_(double x, double sigma, double mu){
    double psi = exp(-pow((x-mu),2)/(2*sigma*sigma))+exp(-pow(x+mu,2)/(2*sigma*sigma));
    return psi;
}

double esponenziale(double x, double y, double sigma, double mu){
    double p = (exp(-pow((x+y*mu),2)/(2*sigma*sigma)));
    return p;
}

double K(double x, double sigma, double mu){
        double p=(-1/pow(sigma,2)+pow(x-mu,2)/pow(sigma,4))*esponenziale(x,-1,sigma,mu)+(-1/pow(sigma,2)+pow(x+mu,2)/pow(sigma,4))*esponenziale(x,+1,sigma,mu);
        return p;
    }
                   
double potenziale (double x) {return (x*x*x*x-5/2*x*x);}

void ciclo(double*vettore_posizioni, double*xvett, double M, double sigma, double mu, double delta){
    double x,xnew;
    Random rnd;
    rnd.Random_std(&rnd);
        for (int j=0; j<M;j++){
            //if(j%1000==0) cout<<j/100<<"%"<<endl;
            x = 0;
            for(int i=0; i<1000; i++){
                
                xnew=rnd.Rannyu(x-delta, x+delta);
                double a=min(1., P(xnew, sigma, mu)/P(x, sigma, mu));
                
                if(rnd.Rannyu() <= a){
                    x = xnew;
                }
                vettore_posizioni[j*1000+i]=x;
                xvett[j*1000+i]=potenziale(x)-0.5*K(x,sigma,mu)/sqrt((2*sigma*sqrt(M_PI)*(1+exp(-mu*mu/sigma/sigma))));

            }
        }
    }



int main(){

    ofstream posizioni;
    Random rnd;
    rnd.Random_std(&rnd);
    int M=100;
    double x, xnew;
    double * xvett = new double[M*1000];
    double*vettore_posizioni = new double[M*1000];
    double delta = 2.8;
    int nacc= 0;
    blocchi Psi(M*1000,M);
    //come posizione iniziale uso il raggio medio
// ground state uni
    
    double sigma=0.65;
    double mu = 0.75;
    
    ciclo(vettore_posizioni, xvett,  M,  sigma,  mu,  delta);
    Psi.do_it(xvett);
    double energia = Psi.get(99);
    cout<<energia<<endl;
    ///////////////////
    double mu_ = mu;
    double sigma_ = sigma;
    double energia_;
    
    for(int i=0; i<5000; i++){
        mu_+= rnd.Rannyu(-0.2,0.2);
        sigma_+= rnd.Rannyu(-0.2,0.2);
        if(mu_<0) mu_*=-1;
        if(sigma_<0) sigma_*=-1;
        ciclo(vettore_posizioni, xvett,  M,  sigma_,  mu_,  delta);
        
        Psi.do_it(xvett);
        energia_ = Psi.get(99);
        
        if (energia_<energia){
            mu=mu_;
            sigma=sigma_;
            energia=energia_;
        }
        cout<<energia<<","<<energia_<<endl;
    }
    
    cout<<mu<<","<<sigma<<endl;
    cout<<energia<<endl;
    ciclo(vettore_posizioni, xvett,  M,  sigma,  mu,  delta);
    Psi.do_it(xvett);
     ///////////////
    Psi.stampa("min_<H>");
    posizioni.open("posizioni.dat");
    for (int j=0; j<M*1000;j++) posizioni<<vettore_posizioni[j]<<endl;
    posizioni.close();
    
    return 0;
}
