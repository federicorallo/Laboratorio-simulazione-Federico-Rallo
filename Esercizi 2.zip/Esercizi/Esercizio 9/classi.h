
#ifndef _CLASSI_H
#define _CLASSI_H

using namespace std;
#include <iostream>
#include <cstring>
#include <fstream>
#include "random.h"


struct posizioni {
  int indice;
  double x;
  double y;
  
};


class GA {
public:
    //costruttori
    GA (int);
    
	void generate_cfr(void);
    void generate_square(void);
    void generate_paths(void);
    void distance(void);
    void check(void);
    void print(int);
    void distance_check(int);
    void print_path(void);
    void do_it (double * vettore);
    void ordina(void);
    void permute(void);
    void swap(void);
    void shift(void);
    void invert(void);
    void print_distance1(void);
    void mutation(void);
    //void crossover(int, int, int, int);
    void cross_over(void);
    void print_bestpath(void);
    int Select(void);
    void print_L(void);
    
    /*double get_error(int indice);
    double get(int indice);
    void stampa(string nomefile);
    */
protected:
    int n_city;
    Random rnd;
    int _num = 32;;
    posizioni * _city;
    double distance_;
    double *vettore_distanze;
    int **matrice;
    int **matrice_cross;
    int **matrice_back;
    double ** _percorsiOld;
};





// lista di cose da fare
/*
generare le città nei due modi
calcolare la lunghezza del percorso
ordinare il vettore delle lunghezze
media delle lunghezze

 i quattro algoritmi
 
 
 
*/
#endif
