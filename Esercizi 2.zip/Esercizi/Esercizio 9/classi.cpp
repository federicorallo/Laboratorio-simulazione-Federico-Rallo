#include "classi.h"
#include "random.h"

#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <cstring>
#include <iostream>


using namespace std;



//*********COSTRUTTORI***********//

double single_distance (posizioni a, posizioni b){
    double d = sqrt(pow((a.x - b.x), 2) + pow((a.y - b.y), 2));
    return d;
}




GA::GA(int city){
    
    n_city = city;
    _city = new posizioni [n_city+1];
    
    rnd.Random_std(&rnd);

}

void GA::generate_cfr() {
    for(int i=0; i<n_city; i++){
    double a = rnd.Rannyu()*2;
    double b = rnd.Rannyu();
    double c = rnd.Rannyu();

    _city[i].y = sin(asin(1-a));
    _city[i].x = cos(asin(1-a));
    if(b<0.5) _city[i].x*=-1;
    if(c<0.5) _city[i].y*=-1;
        //cout<<_city[i].x<< "  " << _city[i].y <<endl;
    }
}
void GA::generate_square() {
    for(int i=0; i<n_city; i++){
    double a = rnd.Rannyu();
    double b = rnd.Rannyu();

    _city[i].y = a;
    _city[i].x = b;

    }
}

void GA::generate_paths() {

    matrice = new int * [100];
    for (int i=0 ; i<100 ; i++){
        matrice[i] = new int[33];
    }
    for (int i=0; i<n_city;i++){
        matrice[0][i] = i;
    }
    for (int i=1;i<100; i++){
        for (int j=0; j<n_city; j++){
            matrice[i][j]=matrice[i-1][j];
        }
        
        int b = int(rnd.Rannyu()*(double(n_city-2))+1);
        int c = matrice[i][b];
        matrice[i][b] = matrice[i][b+1];
        matrice[i][b+1] = c;
        }
    //-------------------------------------------
    matrice_cross = new int * [100];
    for (int i=0 ; i<100 ; i++){
        matrice_cross[i] = new int[33];
    }
    matrice_back = new int * [100];
    for (int i=0 ; i<100 ; i++){
        matrice_cross[i] = new int[33];
    }
    
    /*for (int i=0; i<100;i++) {
        for (int j=0; j<32;j++) cout<<matrice[i][j]<<" , ";
    }*/
}


void GA::distance() {
    vettore_distanze = new double[100];
    //calcola le distanze di tutti i percorsi
    for (int j=0; j<100;j++){
    distance_ = 0;
        

        for(int i=0; i<n_city-1; i++){
            distance_+= single_distance(_city[matrice[j][i+1]],_city[matrice[j][i]] );

        }
        distance_ += single_distance(_city[matrice[j][n_city-1]],_city[0]);
        vettore_distanze[j]=distance_;

    }

}

void GA::distance_check(int j){
double check_distance = 0;
for(int i=0; i<n_city-1; i++){
        check_distance+= sqrt(pow(_city[matrice[j][i+1]].x-_city[matrice[j][i]].x,2)+pow(_city[matrice[j][i+1]].y-_city[matrice[j][i]].y,2));
        }

    check_distance+= sqrt(pow(_city[matrice[j][n_city-1]].x-_city[0].x,2)+pow(_city[matrice[j][n_city-1]].y-_city[0].y,2));
cout<<check_distance<<endl;
    }





//funzioni di controllo!
//
void GA::check() {
    double * vett = new double[n_city];

    
    for (int i=0; i<100;i++){
        for (int z=0; z<n_city; z++) vett[z]=0;
        for (int j=0; j<n_city; j++){
            int a = matrice[i][j];
            vett[a]++;
            if (vett[a]==2){cout<<"errore!! Nella "<<i<<" riga"<<endl;}
        }
    }
    //for (int i=0; i<32;i++) cout<<matrice[0][i]<<" , ";
    //cout<<endl<<endl<<vettore_distanze[0]<<endl;
}

void GA::print(int n){
    for (int i=0; i<32; i++) {cout<<matrice[n][i]<<endl;}
}
        




void GA::ordina(){
        int posMin;
            double *appo = new double[n_city];
            double app;
        for (int m=0; m<100; m++){
            posMin=m;
            for (int i=m; i<100; i++){
                if (vettore_distanze[posMin]>vettore_distanze[i]) posMin=i;
            }
            
            for (int ii=1; ii<n_city; ii++){
                appo[ii] = matrice[posMin][ii];
                matrice[posMin][ii] = matrice[m][ii];
                matrice[m][ii] = appo[ii];
            }
            app =vettore_distanze[posMin];
            vettore_distanze[posMin] = vettore_distanze[m];
            vettore_distanze[m]=app;
    }
    //for (int i=0; i<100;i++) cout<<vettore_distanze[i]<<";"; cout<<endl;

    //for (int i=0; i<32;i++) cout<<vettore_distanze[i]<<";"; cout<<endl;
    //for (int ii=0; ii<100;ii++) cout<<vettore_distanze[ii]<<" , ";
    //cout<<vettore_distanze[0]<<endl;
    //cout<<endl<<endl<<endl;;
}

void GA::print_path(){
    
    for (int i=0; i<100; i++) cout<<vettore_distanze[i]<<endl;
}


void GA::print_distance1(){
    double d=0;
    d=vettore_distanze[0];
    cout<<d<<endl;
}



void GA::swap(){
    for (int i=0; i<100;i++){

        double c = rnd.Rannyu();
        if(c<0.1){
            int a = (rnd.Rannyu(1,n_city-1));
            int b = (rnd.Rannyu(1,n_city-1));
            
            double d = matrice[i][a];
            matrice[i][a] = matrice[i][b];
            matrice[i][b]=d;
        }
    }
}

void GA::shift(){
    for (int i=0; i<100;i++){
        double c = rnd.Rannyu();
        if(c<0.1){
            double *appo = new double[n_city];
            for (int j=0; j<n_city;j++) appo[j]=matrice[i][j];
            int b = (rnd.Rannyu(1,n_city-1));
            for (int z=1; z<n_city; z++){
                int e = b+z;
                if (e>(n_city-1)) e+= -(n_city-1);
                    matrice[i][z]= appo[e];
            }
        }
    }
}

void GA::permute(){
    for (int i=0; i<100; i++){
        double c = rnd.Rannyu();

        if(c<0.1){
            
            int a = rnd.Rannyu(1,n_city/2);
            int b = (rnd.Rannyu(1,n_city-1));

            
            for (int z=0; z<a; z++){
                int c= b+z;
                int d= b+z+a;
                if (c > n_city-1) c+=-n_city+1;
                if (d > n_city-1) d+=-n_city+1;

                    double e = matrice[i][c];
                    matrice[i][c] = matrice[i][d];
                    matrice[i][d]=e;
            }
        }

    }
}

void GA::invert(){
    for (int i=0; i<100; i++){
        double c = rnd.Rannyu();
        if(c<0.1){
            
            
            
            int a = rnd.Rannyu(1,(n_city-1)/2);
            int b = 30;
            (rnd.Rannyu(1,n_city-1));
            

            for (int z=0; z<a/2+1; z++){
                double g= b+z;
                double d= b+a-z;
                if (g > n_city-1) g+=-n_city+1;
                if (d > n_city-1) d+=-n_city+1;
                if (g < 1) g+=n_city-1;
                if (d < 1) d+=n_city-1;
                                
                double e = matrice[i][int(g)];
                matrice[i][int(g)] = matrice[i][int(d)];
                matrice[i][int(d)]=e;
            }
            
            
        }

    }
}



void GA::cross_over(){
    
    for(int i=0; i<50;i++){
        double f = rnd.Rannyu();
        int a = int(pow(rnd.Rannyu(),2)*100);
        int b = int(pow(rnd.Rannyu(),2)*100);
        double*m1 = new double[n_city];
        double*m2 = new double[n_city];
        for (int j=0; j<n_city;j++){
            m1[j] = matrice[a][j];
            m2[j] = matrice[b][j];
        }
        
        
        if (f<0.70){
            int c = (rnd.Rannyu(1,n_city-1));

            int conto = c;
            
            for (int j=0; j<n_city; j++){
                int d = matrice[a][j];

                if(c==((n_city))) break;
                
                for (int k=0; k<c; k++){
                    if (d == matrice[b][k]){
                        break;
                    }
                    //cout<<d<<endl;
                    if(k==c-1) {
                        matrice[b][c] = d;

                        c++;
                        break;
                    }
                }
            }
        
            c = conto;
            for (int j=0; j<n_city; j++){
                int d = matrice[b][j];
                if(c==(n_city)) break;
                
                for (int k=0; k<c; k++){
                    if (d == matrice[a][k]){
                        break;
                    }
                    if(k==(c-1)) {
                        matrice[a][c]=d;
                        c++;
                        break;
                    }
                }
            }
        }
        for (int j=0; j<n_city; j++){
            matrice_cross[2*i][j] = matrice[a][j];
            matrice_cross[2*i+1][j] = matrice[b][j];
            matrice[a][j] = m1[j];
            matrice[b][j] = m2[j];
        }
    }
    for (int i=0; i<100;i++){
        for (int j=0; j<n_city;j++) matrice[i][j] = matrice_cross[i][j];
    }
}

void GA::print_bestpath(){
    ofstream PrintPath;
    PrintPath.open("bestpath_circ.dat");
    for (int i=0; i<32; i++) PrintPath<< matrice[0][i]<< endl;
    PrintPath.close();
    PrintPath.open("Città_circonferenza.dat");
    for (int i=0; i<n_city; i++) PrintPath<< _city[i].x<< " "<<_city[i].y<<endl;
        PrintPath.close();
    
}

void GA::print_L(){
    ofstream print1, print50;
    print1.open("1.dat",ios::app);
    print50.open("50.dat",ios::app);
    double somma = 0;
    for (int i=0; i<50;i++) somma+=vettore_distanze[i];
    somma/=50.;
    
    print1<<vettore_distanze[0]<<endl;
    print50<<somma<<endl;
    
    print1.close();
    print50.close();
}





//





