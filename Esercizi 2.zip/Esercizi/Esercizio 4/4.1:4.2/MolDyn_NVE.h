/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
//parameters, observables
const int m_props=4;
int n_props;
int iv,ik,it,ie;
double stima_pot, stima_kin, stima_etot, stima_temp;

double*istogramma0=new double[100];
double*istogramma1=new double[100];
double*istogramma2=new double[100];

// averages
double acc,att;

//configuration
const int m_part=108;
double x[m_part],y[m_part],z[m_part],xold[m_part],yold[m_part],zold[m_part];
double vx[m_part],vy[m_part],vz[m_part];

// thermodynamical state
int npart;
double energy,temp,vol,rho,box,rcut;

//medie
double *v_pot, *v_kin, *v_temp, *v_tot;
double *er_pot, *er_kin, *er_temp, *er_tot;
double *av_pot, *av_kin, *av_temp, *av_tot;

int nblocks, lenght, contatore;

int ciclo;
double start_;

// simulation
int nstep, iprint, seed;
double delta;

//functions
void Input(int);
void Move(void);
void ConfFinal(int);
void ConfXYZ(int);
void Measure(int);
double Force(int, int);
double Pbc(double);


/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
