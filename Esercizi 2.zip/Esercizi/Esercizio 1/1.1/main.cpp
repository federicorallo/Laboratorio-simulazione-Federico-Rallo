
using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"


int main(){
    
    int M=1000000;            // Total number of throws
    int N=100;        // Number of blocks
    int L=(M/N);          // Number of throws in each block, please use for M a multiple of N
    
    double*r = new double [M*10];      // [0,1,2,...,N-1]
    double*ave = new double[L];
    double*ave2 = new double[L];

    double*err_prog = new double[N];

    double*sum_prog= new double [N];
    double*su2_prog= new double [N];
    
    
    //creo un vettore di M numeri casuali
    Random rnd;
    int seed[4];
    int p1, p2;
    ifstream Primes("Primes");
    if (Primes.is_open()){
       Primes >> p1 >> p2 ;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
       while ( !input.eof() ){
          input >> property;
          if( property == "RANDOMSEED" ){
             input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
             rnd.SetRandom(seed,p1,p2);
          }
       }
       input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;

    for(int i=0; i<M*10; i++){
        r[i] = rnd.Rannyu();
    }

    rnd.SaveSeed();
    
    int k=0;

    double s;
    for(int i=0; i<N; i++){
        s=0;
    for (int j=0; j<L; j++){
        k = j+i*L;
        s += r[k];
        ave[i] = s/L;       // r_i
        ave2[i] = pow((ave[i]),2); // (r_i)^2
        }
    }
    /*ofstream fout("dati.dat");
    for(int i=0; i<N; i++){
    fout<< ave[i] <<endl;
    }*/

    for (int i=0 ; i<N; i++){
        sum_prog[i]=0;
        su2_prog[i]=0;
    }
    

    
        for (int i=0; i<N; i++){
            for (int j=0; j<i+1; j++){
                 // SUM_{j=0,i} (r_j)^2

                sum_prog[i]+=ave[j]; // SUM_{j=0,i} r_j
                
                su2_prog[i]+=ave2[j]; // SUM_{j=0,i} (r_j)^2
            }
                
            sum_prog[i]/=(i+1); // Cumulative average
            su2_prog[i]/=(i+1); // Cumulative square average
      
            err_prog[i] = sqrt((su2_prog[i] - pow(sum_prog[i],2)));
            err_prog[i]/= sqrt(i+1); // Statistical uncertainty

        }
            ofstream fout("dati.dat");
                          for(int i=0; i<N; i++){
                          fout<< sum_prog[i] <<" "<< err_prog[i]<<endl;
                          }
    fout.close();
    
    //ERROR
    
    double ave_s[L];
    double ave_s2[L];
    double sum_progs[N];
    double su2_progs[N];
    double err_progs[N];
    double somma=0;

    for (int i=0; i<N; i++){
        somma = 0;
        for (int j=0; j<L; j++){
            k = j+i*L;
            somma += pow((r[k]-0.5),2); // Accumulate measures
            ave_s[i] = somma/L;           // Estimate in each block
            ave_s2[i] = pow(ave_s[i],2);
        }
    }
    
    for (int i=0; i<N ;i++){
        for (int j=0; j<i+1; j++){
            sum_progs[i] += ave_s[j];
            su2_progs[i] += ave_s2[j];
        }
        sum_progs[i]/=(i+1); // Cumulative average
        su2_progs[i]/=(i+1); // Cumulative square average
        err_progs[i] = sqrt((su2_progs[i] - pow(sum_progs[i],2)));
        err_progs[i]/= sqrt(i+1);
        
    }
    
    ofstream fout2("dati2.dat");
    for(int i=0; i<N; i++){
    fout2<< sum_progs[i] <<" "<< err_progs[i]<<endl;
    }
    fout2.close();
    
    // CHI QUADRO
    
    int I=100; //intervalli
    
    
    double chi_2[N];
    
    int n_[I];
    for (int i=0; i<I; i++){
        n_[i]=0;
    }

    int zz=0;
    
    
    for (int j=0; j<N; j++){
        chi_2[j]=0;
        
        for (int y=0; y<I; y++){
            for (int z=0; z<10000; z++){
                zz = z+j*L;
                if (r[zz]>(y*0.01) && r[zz]<((y+1)*0.01)){
                    n_[y]+=1;
                }
            }
            
        }
        for (int i=0; i<I; i++){
            chi_2[j]= pow(((double(n_[i]))-10000./100.),2)/(10000./100.)+chi_2[j];
            n_[i]=0;
        }
    }
    
    ofstream fout3("dati3.dat");
    for(int i=0; i<N; i++){
    fout3<< chi_2[i] <<" "<<endl;
    }
    fout3.close();
    
    double chi_quadro=0;
    for(int i=0; i<100;i++) chi_quadro+=chi_2[i];
    cout<<chi_quadro/100.<<endl;
    
    return 0;
}

