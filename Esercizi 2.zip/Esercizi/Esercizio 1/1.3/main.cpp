//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "blocchi.h"

int main(){
    Random rnd;
    
    
       int seed[4];
       int p1, p2;
       ifstream Primes("Primes");
       if (Primes.is_open()){
          Primes >> p1 >> p2 ;
       } else cerr << "PROBLEM: Unable to open Primes" << endl;
       Primes.close();

       ifstream input("seed.in");
       string property;
       if (input.is_open()){
          while ( !input.eof() ){
             input >> property;
             if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
             }
          }
          input.close();
       } else cerr << "PROBLEM: Unable to open seed.in" << endl;
       rnd.SaveSeed();
    
  
    
    double x0;
    double x1;
    double x2;
    double _x;
    
    double l=1;
    double d=2;
    int contatore=0;
    int M=100000;
    double vettore_[M-10000];
    blocchi pigreco(M-10000,100);
    
    for (int i=0; i<M; i++){
        x1 = rnd.Rannyu();
        x2 = rnd.Rannyu();
        
        if (sqrt(pow(x1,2)+pow(x2,2))<1){
        x0 =rnd.Rannyu()*2;    //la x0 in cui cade l'estremo destro del bastoncino
        _x= x1/(sqrt(pow(x1,2)+pow(x2,2)));
        if (_x+x0>2) contatore+=1;
        }
        else i=i-1;
        if(i>9999)
        vettore_[i-10000]=(2.*l/d)*double(i)/double(contatore);

    }
    
    pigreco.do_it(vettore_);
    pigreco.stampa("pigreco.dat");

    cout<<(2*l/d)*double(M)/contatore<<endl;
    
    ofstream Output;
    Output.open("pi.dat");
    Output<<(2*l/d)*double(M)/contatore<<endl;
    Output.close();
    
    return 0;
}
