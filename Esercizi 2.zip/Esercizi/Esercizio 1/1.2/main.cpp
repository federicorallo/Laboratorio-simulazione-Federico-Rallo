//
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"


int main(){
    Random rnd;
    
    int M=10000;
    int O=100;
    
    
    
       int seed[4];
       int p1, p2;
       ifstream Primes("Primes");
       if (Primes.is_open()){
          Primes >> p1 >> p2 ;
       } else cerr << "PROBLEM: Unable to open Primes" << endl;
       Primes.close();

       ifstream input("seed.in");
       string property;
       if (input.is_open()){
          while ( !input.eof() ){
             input >> property;
             if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
             }
          }
          input.close();
       } else cerr << "PROBLEM: Unable to open seed.in" << endl;
       rnd.SaveSeed();
    
    //DISTRIBUZIONE NORMALE
    
    double numeri_rand[O][M];
    double num = 0;
    
    for (int j=0; j<O; j++){
        for (int i=0; i<M; i++){
            numeri_rand[j][i] = 0;
        }
    }
    
    for (int i=0; i<M; i++){
    numeri_rand[0][i]=rnd.Rannyu();
    }
    

    for (int i=0; i<M; i++){
        for (int j=0; j<O-1; j++){
            num=rnd.Rannyu();
            numeri_rand [j+1][i] = numeri_rand [j][i] + num;
        }
    }
   
    ofstream outData;
    outData.open("dati1.dat");
    outData<<" ";
            outData<<setprecision(6);
    for (int i=0; i<M; i++){
        outData<<numeri_rand[0][i]/1.<<" "<<numeri_rand[1][i]/2.<<" "<<numeri_rand[9][i]/10.<<" "<<numeri_rand[99][i]/100.<<endl;
                 }
        
    outData.close();

    //ESPONENZIALE
    
     for (int j=0; j<O; j++){
         for (int i=0; i<M; i++){
             numeri_rand[j][i] = 0;
         }
     }
     
     for (int i=0; i<M; i++){
     numeri_rand[0][i]=-log(1-rnd.Rannyu());
     }
     

     for (int i=0; i<M; i++){
         for (int j=0; j<O-1; j++){
             num=-log(1-rnd.Rannyu());
             numeri_rand [j+1][i] = numeri_rand [j][i] + num;
         }
     }
    
     outData.open("dati2.dat");
     outData<<" ";
             outData<<setprecision(6);
     for (int i=0; i<M; i++){
             outData<<numeri_rand[0][i]/1.<<" "<<numeri_rand[1][i]/2.<<" "<<numeri_rand[9][i]/10.<<" "<<numeri_rand[99][i]/100.<<endl;
                  }
         
     outData.close();
    
    //LORENZIANA
    
     for (int j=0; j<O; j++){
         for (int i=0; i<M; i++){
             numeri_rand[j][i] = 0;
         }
     }
     
     for (int i=0; i<M; i++){
     numeri_rand[0][i]=atan(rnd.Rannyu())/M_PI+0.5;
     }
     

     for (int i=0; i<M; i++){
         for (int j=0; j<O-1; j++){
             num=atan(rnd.Rannyu())/M_PI+0.5;
             numeri_rand [j+1][i] = numeri_rand [j][i] + num;
         }
     }
    
     outData.open("dati3.dat");
     outData<<" ";
             outData<<setprecision(6);
     for (int i=0; i<M; i++){
             outData<<numeri_rand[0][i]/1.<<" "<<numeri_rand[1][i]/2.<<" "<<numeri_rand[9][i]/10.<<" "<<numeri_rand[99][i]/100.<<endl;
                  }
    return 0;
}
