//
//  classi.cpp
//  
//
//  Created by Federico Rallo on 28/03/2020.
//
#ifndef _CLASSI_HPP_
#define _CLASSI_HPP_

#include "classi.hpp"


using namespace std;
    
public:
    
    g_random( )
    
    
    
}









#endif
