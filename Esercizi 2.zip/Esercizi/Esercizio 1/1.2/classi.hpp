//
//  classi.hpp
//  
//
//  Created by Federico Rallo on 28/03/2020.
//

#ifndef classi_hpp
#define classi_hpp
#include <cstring>
#include <stdio.h>

class g_random {
    
public:
    
    g_random(int N);
    ~g_random ();
    
    double*vettore () const;
}






#endif /* classi_hpp */
