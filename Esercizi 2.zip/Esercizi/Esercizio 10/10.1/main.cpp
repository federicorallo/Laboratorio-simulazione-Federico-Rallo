////
//  main.cpp
//
//
//  Created by Federico Rallo on 28/03/2020.
//

using namespace std;

#include <iostream>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include "random.h"
#include "classi.h"



int main(){
    
    GA ga(32);
    ga.read_city_cfr();
    //ga.read_city_sqrt();
    ga.generate_paths();
    ga.distance();
    ga.check();
    
    for (int indice=0; indice<10000;indice++){
        ga.set_beta(indice*0.01);
        ga.swap();
        ga.shift();
        ga.permute();
        ga.invert();
        
        ga.distance();
        ga.ordina();
        ga.check();
        

        ga.distance();
        ga.ordina();
        
        ga.print_distance1();
        ga.print_bestpath();
        //ga.print(95);

    }

    return 0;
}
